function loadpage(url){
	window.location.assign(url);
}

